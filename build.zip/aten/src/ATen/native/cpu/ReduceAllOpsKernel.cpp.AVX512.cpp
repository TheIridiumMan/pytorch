#include "E:/a/pytorch/pytorch/aten/src/ATen/native/cpu/ReduceAllOpsKernel.cpp"
