#include "H:/pytorch/aten/src/ATen/native/cpu/group_norm_kernel.cpp"
