#include "E:/a/pytorch/pytorch/aten/src/ATen/native/cpu/group_norm_kernel.cpp"
