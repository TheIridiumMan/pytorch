#include "H:/pytorch/aten/src/ATen/native/cpu/StackKernel.cpp"
