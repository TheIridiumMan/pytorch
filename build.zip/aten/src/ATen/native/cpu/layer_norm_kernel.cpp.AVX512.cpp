#include "H:/pytorch/aten/src/ATen/native/cpu/layer_norm_kernel.cpp"
