#include "H:/pytorch/aten/src/ATen/native/cpu/PowKernel.cpp"
