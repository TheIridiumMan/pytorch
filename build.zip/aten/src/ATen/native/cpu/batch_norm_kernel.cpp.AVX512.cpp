#include "H:/pytorch/aten/src/ATen/native/cpu/batch_norm_kernel.cpp"
